package com.sdi.business.impl;

import javax.ejb.Remote;

import com.sdi.business.TasksService;

@Remote
public interface RemoteTaskService extends TasksService{

}
