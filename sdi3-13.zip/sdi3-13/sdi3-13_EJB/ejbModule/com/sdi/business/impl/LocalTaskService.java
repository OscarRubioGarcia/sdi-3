package com.sdi.business.impl;

import javax.ejb.Local;

import com.sdi.business.TasksService;

@Local
public interface LocalTaskService extends TasksService {

}
