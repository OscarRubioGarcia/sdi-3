package com.sdi.business.impl;

import javax.ejb.Local;
import com.sdi.business.CategoriesService;

@Local
public interface LocalCategoryService extends CategoriesService {

}
