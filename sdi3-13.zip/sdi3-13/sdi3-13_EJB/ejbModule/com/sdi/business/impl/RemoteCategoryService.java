package com.sdi.business.impl;

import javax.ejb.Remote;
import com.sdi.business.CategoriesService;

@Remote
public interface RemoteCategoryService extends CategoriesService {

}
