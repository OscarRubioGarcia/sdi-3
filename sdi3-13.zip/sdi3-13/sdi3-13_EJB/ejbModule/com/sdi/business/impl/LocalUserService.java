package com.sdi.business.impl;

import javax.ejb.Local;
import com.sdi.business.UsersService;

@Local
public interface LocalUserService extends UsersService{

}
