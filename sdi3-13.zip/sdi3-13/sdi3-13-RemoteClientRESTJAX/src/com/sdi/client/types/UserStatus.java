package com.sdi.client.types;

public enum UserStatus {

	ENABLED, DISABLED
	
}
